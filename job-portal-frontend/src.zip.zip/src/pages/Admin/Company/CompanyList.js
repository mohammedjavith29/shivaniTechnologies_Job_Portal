import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function CompanyList() {

    const [companies, setCompanies] = useState([]);

    useEffect(() => {
        loadCompanies();
    }, []);

    const loadCompanies = async () => {
        const result = await axios.get("http://localhost:8080/api/companies");
        setCompanies(result.data);
    };

    const deleteCompany = async (id) => {
        await axios.delete(`http://localhost:8080/api/companies/${id}`);
        loadCompanies();
    };

    return (
        <div className="container mt-4">

            <div className="d-flex justify-content-between mb-3">
                <h2>Companies</h2>

                <Link
                    to="/admin/company/add"
                    className="btn btn-primary">
                    Add Company
                </Link>
            </div>

            <table className="table table-bordered table-striped">

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Website</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                    {companies.map(company => (

                        <tr key={company.companyId}>

                            <td>{company.companyId}</td>
                            <td>{company.companyName}</td>
                            <td>{company.email}</td>
                            <td>{company.phone}</td>
                            <td>{company.website}</td>
                            <td>{company.address}</td>

                            <td>

                                <Link
                                    to={`/admin/company/edit/${company.companyId}`}
                                    className="btn btn-warning btn-sm me-2">
                                    Edit
                                </Link>

                                <button
                                    className="btn btn-danger btn-sm"
                                    onClick={() => deleteCompany(company.companyId)}>
                                    Delete
                                </button>

                            </td>

                        </tr>

                    ))}

                </tbody>

            </table>

        </div>
    );
}

export default CompanyList;