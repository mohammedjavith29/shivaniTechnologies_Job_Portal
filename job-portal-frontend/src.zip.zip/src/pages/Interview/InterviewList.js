import React from "react";
import { Link } from "react-router-dom";

function InterviewList() {
  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between mb-3">
        <h2>Interview List</h2>

        <Link
          to="/admin/interview/add"
          className="btn btn-primary"
        >
          Schedule Interview
        </Link>
      </div>

      <table className="table table-bordered table-striped">
        <thead className="table-dark">
          <tr>
            <th>ID</th>
            <th>Candidate</th>
            <th>Company</th>
            <th>Job</th>
            <th>Date</th>
            <th>Status</th>
            <th width="260">Action</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td colSpan="7" className="text-center">
              No Interviews Found
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default InterviewList;