import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

function EditCompany() {

    const { id } = useParams();

    const navigate = useNavigate();

    const [company, setCompany] = useState({
        companyName: "",
        email: "",
        phone: "",
        website: "",
        address: ""
    });

useEffect(() => {
    const fetchCompany = async () => {
        const result = await axios.get(
            `http://localhost:8080/api/companies/${id}`
        );
        setCompany(result.data);
    };

    fetchCompany();
}, [id]);

    const loadCompany = async () => {

        const result = await axios.get(
            `http://localhost:8080/api/companies/${id}`
        );

        setCompany(result.data);
    };

    const handleChange = (e) => {
        setCompany({
            ...company,
            [e.target.name]: e.target.value
        });
    };

    const updateCompany = async (e) => {

        e.preventDefault();

        await axios.put(
            `http://localhost:8080/api/companies/${id}`,
            company
        );

        alert("Company Updated Successfully");

        navigate("/admin/companies");
    };

    return (

        <div className="container mt-4">

            <h2>Edit Company</h2>

            <form onSubmit={updateCompany}>

                <input
                    className="form-control mb-3"
                    name="companyName"
                    value={company.companyName}
                    onChange={handleChange}
                />

                <input
                    className="form-control mb-3"
                    name="email"
                    value={company.email}
                    onChange={handleChange}
                />

                <input
                    className="form-control mb-3"
                    name="phone"
                    value={company.phone}
                    onChange={handleChange}
                />

                <input
                    className="form-control mb-3"
                    name="website"
                    value={company.website}
                    onChange={handleChange}
                />

                <input
                    className="form-control mb-3"
                    name="address"
                    value={company.address}
                    onChange={handleChange}
                />

                <button className="btn btn-primary">
                    Update
                </button>

            </form>

        </div>
    );
}

export default EditCompany;