import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

function EditLocation() {

    const { id } = useParams();

    const navigate = useNavigate();

    const [location, setLocation] = useState({
        locationName: "",
        description: ""
    });

    useEffect(() => {
        loadLocation();
    }, []);

    const loadLocation = async () => {

        const result = await axios.get(
            `http://localhost:8080/api/locations/${id}`
        );

        setLocation(result.data);

    };

    const handleChange = (e) => {

        setLocation({
            ...location,
            [e.target.name]: e.target.value
        });

    };

    const updateLocation = async (e) => {

        e.preventDefault();

        await axios.put(
            `http://localhost:8080/api/locations/${id}`,
            location
        );

        alert("Location Updated Successfully");

        navigate("/admin/locations");

    };

    return (

        <div className="container mt-5">

            <div className="card shadow">

                <div className="card-body">

                    <h2>Edit Job Location</h2>

                    <form onSubmit={updateLocation}>

                        <div className="mb-3">

                            <label>Location Name</label>

                            <input
                                type="text"
                                className="form-control"
                                name="locationName"
                                value={location.locationName}
                                onChange={handleChange}
                                required
                            />

                        </div>

                        <div className="mb-3">

                            <label>Description</label>

                            <textarea
                                className="form-control"
                                rows="4"
                                name="description"
                                value={location.description}
                                onChange={handleChange}
                            />

                        </div>

                        <button className="btn btn-success">
                            Update Location
                        </button>

                    </form>

                </div>

            </div>

        </div>

    );

}

export default EditLocation;