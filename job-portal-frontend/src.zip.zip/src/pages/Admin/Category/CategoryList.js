import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function CategoryList() {

    const [categories, setCategories] = useState([]);

    useEffect(() => {

        loadCategories();

    }, []);

    const loadCategories = async () => {

        const result = await axios.get(
            "http://localhost:8080/api/categories"
        );

        setCategories(result.data);

    };

    const deleteCategory = async (id) => {

        if (window.confirm("Delete this category?")) {

            await axios.delete(
                `http://localhost:8080/api/categories/${id}`
            );

            loadCategories();

        }

    };

    return (

        <div className="container mt-4">

            <div className="d-flex justify-content-between mb-3">

                <h2>Job Categories</h2>

                <Link
                    to="/admin/categories/add"
                    className="btn btn-primary">

                    Add Category

                </Link>

            </div>

            <table className="table table-bordered table-hover">

                <thead className="table-dark">

                    <tr>

                        <th>ID</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Actions</th>

                    </tr>

                </thead>

                <tbody>

                    {

                        categories.map((cat) => (

                            <tr key={cat.categoryId}>

                                <td>{cat.categoryId}</td>

                                <td>{cat.categoryName}</td>

                                <td>{cat.description}</td>

                                <td>

                                    <Link
                                        to={`/admin/categories/edit/${cat.categoryId}`}
                                        className="btn btn-warning btn-sm me-2">

                                        Edit

                                    </Link>

                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => deleteCategory(cat.categoryId)}>

                                        Delete

                                    </button>

                                </td>

                            </tr>

                        ))

                    }

                </tbody>

            </table>

        </div>

    );

}

export default CategoryList;