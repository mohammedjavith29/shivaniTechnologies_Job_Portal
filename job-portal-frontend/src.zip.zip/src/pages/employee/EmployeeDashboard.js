import React from "react";

function EmployeeDashboard() {
    return (
        <div className="container mt-5">
            <h2>Employee Dashboard</h2>
            <h4>Welcome, {localStorage.getItem("username")}</h4>
        </div>
    );
}

export default EmployeeDashboard;