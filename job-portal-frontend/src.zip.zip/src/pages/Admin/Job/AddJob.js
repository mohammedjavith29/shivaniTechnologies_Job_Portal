import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { addJob } from "../../../services/jobService";

function AddJob() {

    const navigate = useNavigate();

    const [job, setJob] = useState({

        jobTitle:"",
        salary:"",
        experience:"",
        jobType:"",
        description:"",
        status:true

    });

    const handleChange=(e)=>{

        setJob({

            ...job,

            [e.target.name]:e.target.value

        });

    }

    const handleSubmit=(e)=>{

        e.preventDefault();

        addJob(job)
        .then(()=>navigate("/admin/jobs"))
        .catch(err=>console.log(err));

    }

    return(

        <div className="container mt-4">

            <h2>Add Job</h2>

            <form onSubmit={handleSubmit}>

                <input
                    className="form-control mb-3"
                    placeholder="Job Title"
                    name="jobTitle"
                    onChange={handleChange}
                />

                <input
                    className="form-control mb-3"
                    placeholder="Salary"
                    name="salary"
                    onChange={handleChange}
                />

                <input
                    className="form-control mb-3"
                    placeholder="Experience"
                    name="experience"
                    onChange={handleChange}
                />

                <input
                    className="form-control mb-3"
                    placeholder="Job Type"
                    name="jobType"
                    onChange={handleChange}
                />

                <textarea
                    className="form-control mb-3"
                    placeholder="Description"
                    name="description"
                    onChange={handleChange}
                />

                <button className="btn btn-success">

                    Save Job

                </button>

            </form>

        </div>

    );

}

export default AddJob;