import React from "react";

function CandidateDashboard() {
    return (
        <div className="container mt-5">
            <h2>Candidate Dashboard</h2>
            <h4>Welcome, {localStorage.getItem("username")}</h4>
        </div>
    );
}

export default CandidateDashboard;