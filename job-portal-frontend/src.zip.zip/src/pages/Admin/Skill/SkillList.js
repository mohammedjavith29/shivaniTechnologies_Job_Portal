import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function SkillList() {

    const [skills, setSkills] = useState([]);

    useEffect(() => {
        loadSkills();
    }, []);

    const loadSkills = async () => {
        const result = await axios.get("http://localhost:8080/api/skills");
        setSkills(result.data);
    };

    const deleteSkill = async (id) => {
        await axios.delete(`http://localhost:8080/api/skills/${id}`);
        loadSkills();
    };

    return (
        <div className="container mt-4">

            <div className="d-flex justify-content-between mb-3">
                <h2>Skills</h2>

                <Link
                    to="/admin/skill/add"
                    className="btn btn-primary">
                    Add Skill
                </Link>
            </div>

            <table className="table table-bordered">

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Skill Name</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                    {skills.map(skill => (

                        <tr key={skill.skillId}>

                            <td>{skill.skillId}</td>
                            <td>{skill.skillName}</td>

                            <td>

                                <Link
                                    className="btn btn-warning btn-sm me-2"
                                    to={`/admin/skill/edit/${skill.skillId}`}>
                                    Edit
                                </Link>

                                <button
                                    className="btn btn-danger btn-sm"
                                    onClick={() => deleteSkill(skill.skillId)}>
                                    Delete
                                </button>

                            </td>

                        </tr>

                    ))}

                </tbody>

            </table>

        </div>
    );
}

export default SkillList;