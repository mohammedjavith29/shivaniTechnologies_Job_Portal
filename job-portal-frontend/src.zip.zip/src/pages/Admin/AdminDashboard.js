import React from "react";
import { useNavigate } from "react-router-dom";

function AdminDashboard() {
  const navigate = useNavigate();

  const username = localStorage.getItem("username");

return (
  <div className="container mt-5">

    <h1 className="text-primary">
      Admin Dashboard
    </h1>

    <h3>
      Welcome {username}
    </h3>

    <hr />

    <div className="row">

      <div className="col-md-3">
        <div className="card">
          <div className="card-body">
            <h5>Total Users</h5>
            <h2>0</h2>
          </div>
        </div>
      </div>

      <div className="col-md-3">
        <div className="card">
          <div className="card-body">
            <h5>Total Companies</h5>
            <h2>0</h2>
          </div>
        </div>
      </div>

    </div>

    <button
      className="btn btn-danger mt-4"
      onClick={logout}
    >
      Logout
    </button>

  </div>
);
}

export default AdminDashboard;