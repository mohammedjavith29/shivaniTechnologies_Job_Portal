import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { register } from "../../services/authService";

function Register() {

    const navigate = useNavigate();

const [user, setUser] = useState({

    username: "",
    email: "",
    mobile: "",
    password: "",
    role: "CANDIDATE"

});

    const handleChange = (e) => {

        setUser({
            ...user,
            [e.target.name]: e.target.value
        });

    };

  const handleSubmit = async (e) => {

    e.preventDefault();

    try {

        const response = await register(user);

        alert(response);

        navigate("/login");

    } catch (error) {

        if (error.response) {

            alert(error.response.data);

        } else {

            alert("Cannot connect to Spring Boot Backend");

        }

    }

};

    return (

        <div className="container mt-5">

            <div className="row justify-content-center">

                <div className="col-md-6">

                    <div className="card shadow">

                        <div className="card-body">

                            <h2 className="text-center mb-4">
                                Register
                            </h2>

                            <form onSubmit={handleSubmit}>

                                <div className="mb-3">

                                    <label className="form-label">
                                        Username
                                    </label>

                                    <input
                                        type="text"
                                        name="username"
                                        className="form-control"
                                        value={user.username}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="mb-3">

                                    <label className="form-label">
                                        Email
                                    </label>

                                    <input
                                        type="email"
                                        name="email"
                                        className="form-control"
                                        value={user.email}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="mb-3">

                                    <label className="form-label">
                                        Mobile
                                    </label>

                                    <input
                                        type="text"
                                        name="mobile"
                                        className="form-control"
                                        value={user.mobile}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="mb-3">

                                    <label className="form-label">
                                        Password
                                    </label>

                                    <input
                                        type="password"
                                        name="password"
                                        className="form-control"
                                        value={user.password}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="mb-3">

                                    <label className="form-label">
                                        Role
                                    </label>

<select
    name="role"
    className="form-select"
    value={user.role}
    onChange={handleChange}
>

    <option value="CANDIDATE">
        Candidate
    </option>

    <option value="EMPLOYER">
        Employer
    </option>

</select>

                                </div>

                                <button
                                    type="submit"
                                    className="btn btn-success w-100"
                                >
                                    Register
                                </button>

                            </form>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    );

}

export default Register;