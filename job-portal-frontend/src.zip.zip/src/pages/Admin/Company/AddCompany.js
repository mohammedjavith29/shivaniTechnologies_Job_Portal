import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function AddCompany() {

    const navigate = useNavigate();

    const [company, setCompany] = useState({
        companyName: "",
        email: "",
        mobile: "",
        website: "",
        address: "",
        city: "",
        state: "",
        country: "",
        verified: false
    });

    const handleChange = (e) => {
        setCompany({
            ...company,
            [e.target.name]: e.target.value
        });
    };

    const saveCompany = async (e) => {

        e.preventDefault();

        try {

            console.log(company);

            await axios.post(
                "http://localhost:8080/api/companies",
                company
            );

            alert("Company Added Successfully");

            navigate("/admin/companies");

        } catch (error) {

            console.log(error);

            if (error.response) {
                console.log(error.response.data);
                alert("Error : " + JSON.stringify(error.response.data));
            } else {
                alert("Cannot connect to Spring Boot");
            }

        }

    };

    return (

        <div className="container mt-5">

            <div className="card shadow">

                <div className="card-body">

                    <h2 className="mb-4">Add Company</h2>

                    <form onSubmit={saveCompany}>

                        <div className="mb-3">
                            <label>Company Name</label>
                            <input
                                type="text"
                                className="form-control"
                                name="companyName"
                                value={company.companyName}
                                onChange={handleChange}
                                required
                            />
                        </div>

                        <div className="mb-3">
                            <label>Email</label>
                            <input
                                type="email"
                                className="form-control"
                                name="email"
                                value={company.email}
                                onChange={handleChange}
                                required
                            />
                        </div>

                        <div className="mb-3">
                            <label>Mobile</label>
                            <input
                                type="text"
                                className="form-control"
                                name="mobile"
                                value={company.mobile}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="mb-3">
                            <label>Website</label>
                            <input
                                type="text"
                                className="form-control"
                                name="website"
                                value={company.website}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="mb-3">
                            <label>Address</label>
                            <textarea
                                className="form-control"
                                rows="2"
                                name="address"
                                value={company.address}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="mb-3">
                            <label>City</label>
                            <input
                                type="text"
                                className="form-control"
                                name="city"
                                value={company.city}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="mb-3">
                            <label>State</label>
                            <input
                                type="text"
                                className="form-control"
                                name="state"
                                value={company.state}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="mb-3">
                            <label>Country</label>
                            <input
                                type="text"
                                className="form-control"
                                name="country"
                                value={company.country}
                                onChange={handleChange}
                            />
                        </div>

                        <button className="btn btn-success">
                            Save Company
                        </button>

                    </form>

                </div>

            </div>

        </div>

    );

}

export default AddCompany;