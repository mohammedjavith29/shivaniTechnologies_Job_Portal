import React from "react";

function Topbar() {
  return (
    <nav className="navbar navbar-light bg-white shadow-sm px-4">
      <h4>Shivani Technologies Job Portal</h4>

      <div>
        Welcome,
        <strong> {localStorage.getItem("username")}</strong>
      </div>
    </nav>
  );
}

export default Topbar;