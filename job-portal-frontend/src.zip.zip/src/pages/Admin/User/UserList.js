import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getAllUsers, deleteUser } from "../../../services/userService";

function UserList() {

    const [users, setUsers] = useState([]);

    useEffect(() => {
        loadUsers();
    }, []);

    const loadUsers = async () => {
        const data = await getAllUsers();
        setUsers(data);
    };

    const handleDelete = async (id) => {

        if (window.confirm("Delete this user?")) {
            await deleteUser(id);
            loadUsers();
        }
    };

    return (
        <div className="container mt-4">

            <div className="d-flex justify-content-between mb-3">
                <h2>Users</h2>

                <Link
                    to="/admin/user/add"
                    className="btn btn-primary">
                    Add User
                </Link>
            </div>

            <table className="table table-bordered table-striped">

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                    {users.map(user => (

                        <tr key={user.userId}>

                            <td>{user.userId}</td>
                            <td>{user.username}</td>
                            <td>{user.email}</td>
                            <td>{user.mobile}</td>
                            <td>{user.role?.roleName}</td>

                            <td>

                                <Link
                                    className="btn btn-warning btn-sm me-2"
                                    to={`/admin/user/edit/${user.userId}`}>
                                    Edit
                                </Link>

                                <button
                                    className="btn btn-danger btn-sm"
                                    onClick={() => handleDelete(user.userId)}>
                                    Delete
                                </button>

                            </td>

                        </tr>

                    ))}

                </tbody>

            </table>

        </div>
    );
}

export default UserList;