import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function AddSkill() {

    const navigate = useNavigate();

    const [skill, setSkill] = useState({
        skillName: ""
    });

    const handleChange = (e) => {
        setSkill({
            ...skill,
            [e.target.name]: e.target.value
        });
    };

    const saveSkill = async (e) => {

        e.preventDefault();

        await axios.post(
            "http://localhost:8080/api/skills",
            skill
        );

        alert("Skill Added Successfully");

        navigate("/admin/skills");
    };

    return (

        <div className="container mt-4">

            <h2>Add Skill</h2>

            <form onSubmit={saveSkill}>

                <input
                    className="form-control mb-3"
                    placeholder="Skill Name"
                    name="skillName"
                    onChange={handleChange}
                />

                <button className="btn btn-success">
                    Save Skill
                </button>

            </form>

        </div>

    );
}

export default AddSkill;