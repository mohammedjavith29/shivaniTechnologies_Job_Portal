import React from "react";

function Dashboard() {
  return (
    <div className="container mt-5">
      <div className="card shadow">
        <div className="card-body text-center">
          <h2>Welcome to Shivani Technologies</h2>
          <p>You have successfully logged in.</p>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;