import React from "react";

function AddInterview() {

    return (

        <div className="container mt-5">

            <h2>Add Interview</h2>

            <hr />

            <p>Interview Form Coming Soon...</p>

        </div>

    );

}

export default AddInterview;