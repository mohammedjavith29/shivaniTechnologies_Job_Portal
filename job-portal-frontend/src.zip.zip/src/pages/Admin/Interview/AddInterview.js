import React from "react";

function AddInterview() {
    return (
        <div className="container mt-4">
            <h2>Add Interview</h2>
        </div>
    );
}

export default AddInterview;