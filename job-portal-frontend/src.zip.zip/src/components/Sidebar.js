import React from "react";
import { Link } from "react-router-dom";

function Sidebar() {
  return (
    <div
      className="bg-dark text-white p-3"
      style={{ width: "250px", minHeight: "100vh" }}
    >
      <h3 className="text-center mb-4">Admin Panel</h3>

      <ul className="nav flex-column">

        <li className="nav-item mb-3">
          <Link className="nav-link text-white" to="/admin">
            <i className="bi bi-speedometer2"></i> Dashboard
          </Link>
        </li>

        <li className="nav-item mb-3">
          <Link className="nav-link text-white" to="/users">
            <i className="bi bi-people-fill"></i> Users
          </Link>
        </li>

        <li className="nav-item mb-3">
          <Link className="nav-link text-white" to="/jobs">
            <i className="bi bi-briefcase-fill"></i> Jobs
          </Link>
        </li>

        <li className="nav-item mb-3">
          <Link className="nav-link text-white" to="/companies">
            <i className="bi bi-building"></i> Companies
          </Link>
        </li>

        <li className="nav-item mb-3">
          <Link className="nav-link text-white" to="/applications">
            <i className="bi bi-file-earmark-text"></i> Applications
          </Link>
        </li>

      </ul>
    </div>
  );
}

export default Sidebar;