import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function AddCategory() {

    const navigate = useNavigate();

    const [category, setCategory] = useState({
        categoryName: "",
        description: ""
    });

    const handleChange = (e) => {
        setCategory({
            ...category,
            [e.target.name]: e.target.value
        });
    };

    const saveCategory = async (e) => {
        e.preventDefault();

        try {

            await axios.post(
                "http://localhost:8080/api/categories",
                category
            );

            alert("Category Added Successfully");

            navigate("/admin/categories");

        } catch (error) {

            console.log(error);
            alert("Unable to save category");

        }
    };

    return (

        <div className="container mt-4">

            <h2>Add Category</h2>

            <form onSubmit={saveCategory}>

                <div className="mb-3">

                    <input
                        className="form-control"
                        name="categoryName"
                        placeholder="Category Name"
                        value={category.categoryName}
                        onChange={handleChange}
                        required
                    />

                </div>

                <div className="mb-3">

                    <textarea
                        className="form-control"
                        rows="4"
                        name="description"
                        placeholder="Description"
                        value={category.description}
                        onChange={handleChange}
                    />

                </div>

                <button className="btn btn-success">
                    Save Category
                </button>

            </form>

        </div>

    );

}

export default AddCategory;