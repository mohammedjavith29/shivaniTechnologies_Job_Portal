import axios from "axios";

const API_URL = "http://localhost:8080/api/jobs";

const getToken = () => {
  return localStorage.getItem("token");
};

const config = () => ({
  headers: {
    Authorization: `Bearer ${getToken()}`
  }
});

export const getAllJobs = () => axios.get(API_URL, config());

export const getJobById = (id) =>
  axios.get(`${API_URL}/${id}`, config());

export const addJob = (job) =>
  axios.post(API_URL, job, config());

export const updateJob = (id, job) =>
  axios.put(`${API_URL}/${id}`, job, config());

export const deleteJob = (id) =>
  axios.delete(`${API_URL}/${id}`, config());