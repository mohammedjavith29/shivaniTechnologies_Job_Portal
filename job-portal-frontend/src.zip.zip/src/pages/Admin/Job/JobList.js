import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getAllJobs, deleteJob } from "../../../services/jobService";

function JobList() {

    const [jobs, setJobs] = useState([]);

    useEffect(() => {
        loadJobs();
    }, []);

    const loadJobs = () => {
        getAllJobs()
            .then((res) => setJobs(res.data))
            .catch((err) => console.log(err));
    };

    const removeJob = (id) => {

        if(window.confirm("Delete this Job?")){

            deleteJob(id)
            .then(() => loadJobs())
            .catch(err => console.log(err));

        }
    }

    return (

        <div className="container mt-4">

            <div className="d-flex justify-content-between mb-3">

                <h2>Jobs</h2>

                <Link
                    to="/admin/job/add"
                    className="btn btn-primary">

                    Add Job

                </Link>

            </div>

            <table className="table table-bordered table-striped">

                <thead>

                    <tr>

                        <th>ID</th>
                        <th>Title</th>
                        <th>Salary</th>
                        <th>Experience</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Actions</th>

                    </tr>

                </thead>

                <tbody>

                    {jobs.map(job => (

                        <tr key={job.jobId}>

                            <td>{job.jobId}</td>

                            <td>{job.jobTitle}</td>

                            <td>{job.salary}</td>

                            <td>{job.experience}</td>

                            <td>{job.jobType}</td>

                            <td>

                                {job.status ? "Active" : "Inactive"}

                            </td>

                            <td>

                                <Link

                                    to={`/admin/job/edit/${job.jobId}`}
                                    className="btn btn-warning btn-sm me-2">

                                    Edit

                                </Link>

                                <button

                                    className="btn btn-danger btn-sm"

                                    onClick={()=>removeJob(job.jobId)}>

                                    Delete

                                </button>

                            </td>

                        </tr>

                    ))}

                </tbody>

            </table>

        </div>

    );

}

export default JobList;