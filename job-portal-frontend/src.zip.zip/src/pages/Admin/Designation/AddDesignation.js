import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function AddDesignation() {

    const navigate = useNavigate();

    const [designation, setDesignation] = useState({
        designationName: "",
        description: ""
    });

    const handleChange = (e) => {
        setDesignation({
            ...designation,
            [e.target.name]: e.target.value
        });
    };

    const saveDesignation = async (e) => {

        e.preventDefault();

        try {

            await axios.post(
                "http://localhost:8080/api/designations",
                designation
            );

            alert("Designation Added Successfully");

            navigate("/admin/designations");

        } catch (error) {

            if (error.response) {
                alert(error.response.data);
            } else {
                alert("Cannot connect to Spring Boot");
            }

        }

    };

    return (

        <div className="container mt-5">

            <div className="card shadow">

                <div className="card-body">

                    <h2>Add Job Designation</h2>

                    <form onSubmit={saveDesignation}>

                        <div className="mb-3">

                            <label>Designation Name</label>

                            <input
                                type="text"
                                className="form-control"
                                name="designationName"
                                value={designation.designationName}
                                onChange={handleChange}
                                required
                            />

                        </div>

                        <div className="mb-3">

                            <label>Description</label>

                            <textarea
                                className="form-control"
                                rows="4"
                                name="description"
                                value={designation.description}
                                onChange={handleChange}
                            />

                        </div>

                        <button className="btn btn-success">

                            Save Designation

                        </button>

                    </form>

                </div>

            </div>

        </div>

    );

}

export default AddDesignation;